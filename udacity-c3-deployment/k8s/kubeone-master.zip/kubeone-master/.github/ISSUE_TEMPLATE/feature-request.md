---
name: Feature Request
about: Request a new KubeOne feature
labels: kind/feature

---

<!-- Please use this template if you want to submit a new feature request.-->

**What feature would you like to be added?**

**What are use cases of the feature?**
