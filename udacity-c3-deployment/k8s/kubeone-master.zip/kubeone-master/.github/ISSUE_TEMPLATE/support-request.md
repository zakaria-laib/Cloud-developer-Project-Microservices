---
name: Support Request
about: Use this template if you have questions about KubeOne
labels: triage/support

---

<!-- Please use this template if you need support using KubeOne or if you have any question.

You can also ask us questions on the KubeOne channel on Kubernetes Slack: http://slack.k8s.io/
-->
